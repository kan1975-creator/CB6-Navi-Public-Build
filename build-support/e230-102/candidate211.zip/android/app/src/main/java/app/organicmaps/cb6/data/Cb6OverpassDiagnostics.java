package app.organicmaps.cb6.data;

import android.content.Context;
import android.content.SharedPreferences;

/** Separate endpoint outcome from cache validity. Instrument OverpassSignalProvider only,
 * not CompositeSignalProvider (whose result can be supplied by SQLite or MWM).
 */
public final class Cb6OverpassDiagnostics {
  private static final String PREFS="cb6_overpass_diagnostics_v1";
  private Cb6OverpassDiagnostics() {}
  public static final class Snapshot {
    public final boolean attempted;
    public final long lastAttempt, lastSuccess, lastCount;
    public final String lastError;
    Snapshot(boolean attempted,long attempt,long success,long count,String error) {
      this.attempted=attempted;lastAttempt=attempt;lastSuccess=success;
      lastCount=count;lastError=error;
    }
  }
  /** Hook at the point where a network Overpass response has been parsed successfully. */
  public static void recordSuccess(Context context,long count) {
    if(count<0) throw new IllegalArgumentException("Negative Overpass count");
    long now=System.currentTimeMillis();
    boolean ok=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit()
        .putBoolean("attempted",true).putLong("last_attempt",now)
        .putLong("last_success",now).putLong("last_count",count)
        .remove("last_error").commit();
    if(!ok) throw new IllegalStateException("Overpass diagnostics persist failed");
  }
  /** Hook on Overpass request failure. Never clear the previous successful count. */
  public static void recordFailure(Context context,Exception failure) {
    String type=failure==null?"Unknown":failure.getClass().getSimpleName();
    boolean ok=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit()
        .putBoolean("attempted",true).putLong("last_attempt",System.currentTimeMillis())
        .putString("last_error",type).commit();
    if(!ok) throw new IllegalStateException("Overpass diagnostics persist failed");
  }
  public static Snapshot read(Context context) {
    SharedPreferences p=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
    return new Snapshot(p.getBoolean("attempted",false),p.getLong("last_attempt",-1),
        p.getLong("last_success",-1),p.getLong("last_count",-1),
        p.getString("last_error",""));
  }
}
