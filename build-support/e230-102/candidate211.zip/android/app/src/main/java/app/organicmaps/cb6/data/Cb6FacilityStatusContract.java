package app.organicmaps.cb6.data;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.File;

/** Status contract only. The facility importer must commit this record AFTER verified activation.
 * A record is not evidence that the renderer consumes this database.
 */
public final class Cb6FacilityStatusContract {
  private static final String PREFS = "cb6_facility_status_v1";
  private Cb6FacilityStatusContract() {}

  public static final class Snapshot {
    public final boolean activationRecorded;
    public final boolean filePresent;
    public final long count, updatedAt, size;
    public final String version, detail;
    Snapshot(boolean recorded, boolean present, long count, long updatedAt,
             long size, String version, String detail) {
      this.activationRecorded=recorded; this.filePresent=present;
      this.count=count; this.updatedAt=updatedAt; this.size=size;
      this.version=version; this.detail=detail;
    }
  }

  /** Call only after verified staging and activation. No unverified input is accepted here. */
  public static void recordVerifiedActivation(Context context, String filename,
                                               String version, long count) {
    if (filename==null || !filename.matches("facilities-[0-9a-f]{64}\\.sqlite")
        || version==null || version.isEmpty() || count<0)
      throw new IllegalArgumentException("Invalid facility activation metadata");
    File file=new File(new File(context.getFilesDir(),"cb6-facility-db"),filename);
    if (!file.isFile()) throw new IllegalStateException("Facility DB missing");
    boolean saved=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit()
        .putString("file",filename).putString("version",version)
        .putLong("count",count).putLong("updated",System.currentTimeMillis()).commit();
    if (!saved) throw new IllegalStateException("Facility activation record not persisted");
  }

  public static Snapshot read(Context context) {
    SharedPreferences p=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
    String filename=p.getString("file",null);
    if(filename==null)
      return new Snapshot(false,false,-1,-1,-1,"","施設DBの有効化記録なし（配布・描画接続未実装）");
    if(!filename.matches("facilities-[0-9a-f]{64}\\.sqlite"))
      return new Snapshot(true,false,-1,-1,-1,"","有効化記録のファイル名が不正");
    File file=new File(new File(context.getFilesDir(),"cb6-facility-db"),filename);
    return new Snapshot(true,file.isFile(),p.getLong("count",-1),p.getLong("updated",-1),
        file.isFile()?file.length():-1,p.getString("version",""),
        file.isFile()?"有効化記録あり／描画使用・再検証は未確認":"有効化記録のDBが見つかりません");
  }
}
